package pacman;

import java.util.ArrayList;
import java.util.HashMap;

import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import pacman.m.Game;
import pacman.m.crossing.Node;
import pacman.v.Board;

public class Main extends Application
{

	public static void main(String[] args)
	{
		launch(args);

//		HashMap<Node, Node> nodes = new HashMap<Node, Node>();
//		Node n = new Node(1, 2);
//		Node n2 = new Node(1, 2);
//
//		nodes.put(n, n);
//		System.out.println(nodes.containsKey(n2));

//		ArrayList<Node> nn = new ArrayList<Node>();
//
//		Node n = new Node(1, 2);
//		Node n2 = new Node(1, 2);
//
//		nn.add(n);
//		nn.add(n2);
//		nn.add(n);
//
//		System.out.println(nn.size());
	}

	@Override
	public void start(Stage stage)
	{
		Board scene = new Board(new Pane());
		stage.setScene(scene);
		stage.show();
		new Thread(new Runnable()
		{

			@Override
			public void run()
			{
				new Game(scene);

			}
		}).start();

	}

}
