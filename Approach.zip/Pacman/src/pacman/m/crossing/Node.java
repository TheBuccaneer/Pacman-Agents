package pacman.m.crossing;

import java.util.ArrayList;

public class Node
{
	private int x;
	private int y;

	private ArrayList<Edge> neighbors = new ArrayList<Edge>();

	public Node(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	public int getX()
	{
		return this.x;
	}

	public int getY()
	{
		return this.y;
	}

	public void addNeighbor(Edge e)
	{
		this.neighbors.add(e);
		System.out.println("Neibor Size " + this.neighbors.size());
	}

	@Override
	public int hashCode()
	{
		return 1;
	}

	public boolean equals(Object o)
	{
		if (o instanceof Node)
		{
			Node n = (Node) o;

			return this.x == n.getX() && this.y == n.getY();
		}
		return false;
	}

	public int getNeighborsSize()
	{
		return this.neighbors.size();
	}

	public ArrayList<Edge> getNeighbors()
	{
		return this.neighbors;
	}

}