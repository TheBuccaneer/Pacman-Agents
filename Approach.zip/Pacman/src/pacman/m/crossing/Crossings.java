package pacman.m.crossing;

import java.util.HashMap;

public class Crossings
{

	private Node lastCrossing;
	private HashMap<Node, Node> nodes = new HashMap<Node, Node>();

	public void addCrossing(Node currentNode, int walked)
	{
		if (!this.nodes.containsKey(currentNode))
		{
			this.nodes.put(currentNode, currentNode);
		}

		if (this.lastCrossing != null)
		{

			Node temp = this.nodes.get(currentNode);
			temp.addNeighbor(new Edge(this.lastCrossing, walked));
			this.lastCrossing.addNeighbor(new Edge(temp, walked));
		}

		this.lastCrossing = currentNode;
	}

	public boolean contains(Node n)
	{
		return this.nodes.get(this.lastCrossing) == null ? false : true;
	}

}
