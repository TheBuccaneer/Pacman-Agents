package pacman.m.crossing;

public class Edge
{
	private Node neighbor;
	private int length;

	public Edge(Node src, int length)
	{
		this.neighbor = src;
		this.length = length;
	}

	public Node getNeighbor()
	{
		return this.neighbor;
	}

	public int getLength()
	{
		return this.length;
	}

}
