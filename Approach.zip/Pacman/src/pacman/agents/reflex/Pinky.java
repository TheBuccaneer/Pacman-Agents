package pacman.agents.reflex;

public class Pinky
{

}
