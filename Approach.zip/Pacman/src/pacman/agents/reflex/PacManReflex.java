package pacman.agents.reflex;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import pacman.agents.Agent;
import pacman.m.Game;

public class PacManReflex extends Agent
{
	protected static final String[] IMG_PATHS =
	{ "pacup.png", "pacright.png", "pacdown.png", "pacleft.png" };

	public PacManReflex(int x, int y, int[][] board)
	{
		super(x, y, IMG_PATHS[Agent.RIGHT], board);
	}

	@Override
	public void percept(Game game)
	{
		final int[][] board = game.getBoard(); // model board data

		super.setNewDirection(this.getNextDirection(board), IMG_PATHS, board);

	}

	protected int getNextDirection(int[][] board)
	{
		final int[] dirs = super.getNextPerceptions();

		int highestAction = -1;
		List<Integer> possibleDirection = new ArrayList<Integer>(4);
		possibleDirection.add(-1);

		for (int i = 0; i < 4; i++)
		{
			if (highestAction < dirs[i])
				possibleDirection.clear();
			else if (highestAction > dirs[i])
				continue;

			highestAction = dirs[i];
			possibleDirection.add(i);
		}

		int newDirection = possibleDirection.get(0);
		int numOfSolutions = possibleDirection.size();

		if (numOfSolutions > 1)
			newDirection = possibleDirection.get(new Random().nextInt(numOfSolutions));

		return newDirection;
	}

}