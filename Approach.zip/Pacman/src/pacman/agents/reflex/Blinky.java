package pacman.agents.reflex;

public class Blinky
{

}
