package pacman.agents.modelbased;

import java.util.ArrayList;

import pacman.agents.reflex.PacManReflex;
import pacman.m.Game;
import pacman.m.crossing.Crossings;
import pacman.m.crossing.Edge;
import pacman.m.crossing.Node;

public class PacManModelB extends PacManReflex
{
	private int walked = 0;
	private Crossings crossings = new Crossings();

	public PacManModelB(int x, int y, int[][] board)
	{
		super(x, y, board);
	}

	public void percept(Game game)
	{
		this.walked++;
		final int[][] board = game.getBoard(); // model board data

		int[] percepts = this.getNextPerceptions();
		if (this.isCrossing(percepts))
		{
			System.out.println("CROSSING");
			if (this.isCrossingEmpty(percepts))
			{

				System.out.println("Empty");
			}

			Node currentNode = new Node(this.getX(), this.getY());

		}

		super.setNewDirection(this.getNextDirection(board), IMG_PATHS, board);

	}

	public boolean isCrossingEmpty(int[] perceptions)
	{
		for (Integer I : perceptions)
			if (I == Game.COIN)
				return false;

		return true;
	}

	private boolean isCrossing(int[] perceptions)
	{
		int values = 0;
		for (int i = 0; i < perceptions.length; i++)
			if (perceptions[i] != Game.WALL)
				values++;

		return values > 2 ? true : false;
	}


}
